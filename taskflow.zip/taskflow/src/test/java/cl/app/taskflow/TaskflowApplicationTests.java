package cl.app.taskflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
